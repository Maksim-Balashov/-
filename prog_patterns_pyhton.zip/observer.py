from __future__ import annotations # аннотации типов (python 3.7+)
from abc import ABC, abstractmethod # база для интерфейсов
from typing import List  # Для проверки типа списка подписчиков
from random import randrange # Случайное число из диапазона


class Subject(ABC):
    """
    Интферфейс для издателей.
    Объявляет набор методов для управления подписчиками.
    """

    @abstractmethod
    def attach(self, observer: Observer) -> None:
        """
        Подключение к издателю нового наблюдателя.
        """
        pass

    @abstractmethod
    def detach(self, observer: Observer) -> None:
        """
        Отключение наблюдателя.
        """
        pass

    @abstractmethod
    def notify(self) -> None:
        """
        Уведомление наблюдателей о событии.
        """
        pass


class ConcreteSubject(Subject):
    """
    У Издателя есть некоторый важный параметр и он уведомляет наблюдателей
    когда значение этого параметра измененяется.
    """

    _status: int = None # Параметр храним в этой внутренней переменной

    _observers: List[Observer] = [] # Список подписчиков


    # Реализуем методы управления подписчиками.

    def attach(self, observer: Observer) -> None:
        print("Наблюдатель '{}' подключен.".format(observer))
        self._observers.append(observer)


    def detach(self, observer: Observer) -> None:
        print("Наблюдатель '{}' отключен.".format(observer))
        self._observers.remove(observer)


    # Определяем методы управления подпиской.

    def notify(self) -> None:
        """
        Запуск уведомлений для подписчиков.
        """
        print("Отправка уведомлений...")
        for observer in self._observers:
            observer.update(self)


    def deal(self) -> None:
        """
        Часто логика подписки – не все, что делает Издатель.
        Издатели обыкновенно содержат некоторую важную бизнес-логику, которая
        запускает метод уведомления всякий раз, когда должно произойти или
        уже произошло что-то важное.
        """
        self._status = randrange(0, 10) # Кладем в статус случайное число
        print("\nКому надо {} налетай - подешевело!".format(self._status))
        self.notify()


class Observer(ABC):
    """
    Интерфейс Наблюдателя объявляет метод уведомления, который издатели
    используют для оповещения своих подписчиков.
    """

    @abstractmethod
    def update(self, subject: Subject) -> None:
        """
        Получить обновление от субъекта.
        """
        pass


"""
Разные Наблюдатели по разному реагируют на обновления,
выпущенные Издателем, к которому они подключены.
"""
## Наблюдатель 1
class Observer1(Observer):
    def __init__(self, name="Первый"):
        self._count = 0
        self._name = name


    def __str__(self):
        return self._name


    def update(self, subject: Subject) -> None:
        point = 8
        if subject._status == point:
            print("{}: Я! Я! Мне надо {}!".format(self, point))
            self._count += 1


    def satisfied(self):
        return self._count > 0


    def print_result(self):
        if self._count > 0:
            print("{}: Мне сегодня повезло - взял {}".format(self, self._count))
        else:
            print("{}: Мне сегодня ничего не перепало".format(self))

## Наблюдатель 2
class Observer2(Observer):
    def __init__(self, name="Второй"):
        self._count = 0
        self._name = name


    def __str__(self):
        return self._name


    def update(self, subject: Subject) -> None:
        point = 5
        if subject._status == point:
            print("{}: Моё-моё! {} это мне.".format(self, point))
            self._count += 1


    def satisfied(self):
        return self._count > 1


    def print_result(self):
        if self._count > 0:
            print("{}: Мне сегодня повезло - взял {}".format(self, self._count))
        else:
            print("{}: Мне сегодня ничего не перепало".format(self))


def main():
    subject = ConcreteSubject() # Определяем издателя

    observers = [Observer1(), Observer2()] # Определяем наблюдателей
    for observer in observers:
        subject.attach(observer)       # подключаемся к издателю

    # _ - потому-что нам не важен текущий индекс
    for _ in range(10):  # Первый тур
        subject.deal()    # Делаем дела

    for observer in observers: # Отключаем довольных наблюдателей
        if observer.satisfied(): subject.detach(observer)

    print("\n\nНачинаем второй тур!")
    for _ in range(10):  # Второй тур
        subject.deal()    # Делаем дела

    for observer in observers: # Отключаем довольных наблюдателей
        observer.print_result()


if __name__ == "__main__": # Если скрипт запушен как самостоятельный (не импорт)
    main()            # Запускаем функцию демонстрации
