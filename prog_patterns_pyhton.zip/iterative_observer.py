# чтобы типы определять в удобном месте кода
from __future__ import annotations # отложенные аннотации типов (с версии 3.7)

from abc import ABC, abstractmethod # базовые абстракции для класса и метода
from collections.abc import Iterator # Для итератора
from typing import List, Any  # Типы для аннотаций
from random import randrange # Для наполнения коллекции


class IteratorSubject(Iterator):
    """
    Интферфейс для издателей.
    Объявляет набор методов для управления подписчиками.
    Наследуемся от класса итератора для обеспечения соответствующих
    возможностей в издателях.
    В Iterator'е уже определен абстрактый метод итерирования,
    поэтому здесь его нет.
    """

    @abstractmethod
    def attach(self, observer: Observer) -> None:
        """
        Подключение к издателю нового наблюдателя.
        """
        pass # В интерфейсе методы оставляем пустыми


    @abstractmethod
    def detach(self, observer: Observer) -> None:
        """
        Отключение наблюдателя.
        """
        pass


    @abstractmethod
    def notify(self) -> None:
        """
        Уведомление наблюдателей о событии.
        """
        pass


class ConcreteIteratorSubject(IteratorSubject):
    """
    У Издателя есть некоторый важный параметр и он уведомляет наблюдателей
    когда значение этого параметра измененяется. Теперь этот параметр
    процент прохода по коллекции.
    """

    _observers: List[Observer] = [] # Список подписчиков
    _status: Any = None

    """
    Конкретные Итераторы реализуют различные алгоритмы обхода.
    Эти классы постоянно хранят текущее положение обхода.
    """
    _position: int = None # Текущее положение обхода
    _reverse: bool = False # Направление обхода

    # Реализуем методы необходимые для итератора.

    def __init__(self, collection: List, reverse: bool = False) -> None:
        self._collection = collection # Запоминаем себе коллекцию
        self._reverse = reverse # Запоминаем направление итератора
        self._len = len(collection) # Запоминаем длину коллекции
        self._position = -1 if reverse else 0 # Начальная позиция


    def __next__(self):
        """
        Метод __next __ должен вернуть следующий элемент в последовательности.
        При достижении конца коллекции и в последующих вызовах должно вызываться
        исключение StopIteration, по которому происходит выход и итератора.
        """
        try:
            value = self._collection[self._position]
            self._position += -1 if self._reverse else 1
            self._status = self._collection[self._position]
        except IndexError:
            raise StopIteration()

        self.notify()

        return value


    # Реализуем методы управления подписчиками.

    def attach(self, observer: Observer) -> None:
        print("Наблюдатель {} подключен.".format(observer))
        self._observers.append(observer)


    def detach(self, observer: Observer) -> None:
        print("Наблюдатель {} отключен.".format(observer))
        self._observers.remove(observer)


    # Определяем методы управления подпиской.

    def notify(self) -> None:
        """
        Запуск уведомлений для подписчиков.
        """

        print("Отправка подписчикам статуса '{}'".format(self._status))
        for observer in self._observers:
            observer.update(self)


class Observer(ABC):
    """
    Интерфейс Наблюдателя объявляет метод уведомления, который издатели
    используют для оповещения своих подписчиков.
    """

    @abstractmethod
    def update(self, subject: Subject) -> None:
        """
        Получить обновление от субъекта.
        """
        pass


"""
Разные Наблюдатели по разному реагируют на обновления,
выпущенные Издателем, к которому они подключены.
Разные Наблюдатели по разному реагируют на обновления,
выпущенные Издателем, к которому они подключены.
"""
## Наблюдатель 1
class ObserverPositive(Observer):
    def __init__(self, name="Позитивный", item=None):
        self._item = item
        self._name = name


    def __str__(self):
        return self._name


    def update(self, subject: Subject) -> None:
        point = 8
        if subject._status == self._item:
            print("{}: Ух-ты! Давай ещё {}!".format(self, self._item))


## Наблюдатель 2
class ObserverNegative(Observer):
    def __init__(self, name="Недовольный", item=None):
        self._item = item
        self._name = name


    def __str__(self):
        return self._name


    def update(self, subject: Subject) -> None:
        if subject._status == self._item:
            print(
                "{}: Ё-моё! Говорил-же не надо сюда {} добавлять!".format(
                self, self._item)
            )


def attach_observers(subject, observers):
    for observer in observers:
        subject.attach(observer)       # Подключаем к издателю


def walk_through(collection):
    for i in collection:  # Ходим по итерируемому объекту
        print("\n::{}::".format(i))    # Отображаем текущий элемент


def detach_observers(subject, observers):
    for observer in observers: # Отключаем наблюдателей
        subject.detach(observer)


# Главная демонстрационная функция
def main():
    my_collection = [randrange(10) for _ in range(10)]
    subject = ConcreteIteratorSubject(my_collection, reverse=False) # Издатель
    observers = [
        ObserverNegative(item=3),
        ObserverPositive(item=5),
    ] # Наблюдатели

    attach_observers(subject, observers)
    walk_through(subject)
    detach_observers(subject, observers)


if __name__ == "__main__": # Если скрипт запушен как самостоятельный (не импорт)
    main()            # Запускаем функцию демонстрации
